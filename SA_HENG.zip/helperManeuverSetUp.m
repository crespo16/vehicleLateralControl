% overtaking maneuver

velocity_vehicle_B = 10; % speed of the overtaken vehicle B. Unit: m/s
velocity_right_lane_max = 20; % maximal speed allowed on the right lane
velocity_left_lane_max = 28; % maximal speed allowed on the left lane
man_or_auto = 1; % 0:manual mode,1:autonomous mode
load("Buses_.mat");

